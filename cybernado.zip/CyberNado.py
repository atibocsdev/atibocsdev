import subprocess
import json
import os
import sys
import io

os.system("title CyberNado")

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

art_colors = [
    "\x1b[38;5;160m",
    "\x1b[38;5;166m",
    "\x1b[38;5;172m",
    "\x1b[38;5;178m",
    "\x1b[38;5;184m",
    "\x1b[38;5;190m",
    "\x1b[38;5;220m",
    "\x1b[38;5;226m", 
]

input_colors = [
    "\x1b[38;5;46m",
    "\x1b[38;5;15m", 
    "\x1b[38;5;12m",  
    "\x1b[0m", 
]

def get_ip_info(ip):
    try:
        result = subprocess.run(['curl', '-s', f'ipinfo.io/{ip}'], capture_output=True, text=True, check=True)
        ip_info = json.loads(result.stdout)

        print(f"")
        print(f"{"\x1b[38;5;220m"}════════════════════════════════════════════════════")
        print(f"{"\x1b[38;5;220m"}IP Address: {ip_info.get('ip')}")
        print(f"{"\x1b[38;5;220m"}Hostname: {ip_info.get('hostname')}")
        print(f"{"\x1b[38;5;220m"}City: {ip_info.get('city')}")
        print(f"{"\x1b[38;5;220m"}Region: {ip_info.get('region')}")
        print(f"{"\x1b[38;5;220m"}Country: {ip_info.get('country')}")
        print(f"{"\x1b[38;5;220m"}Location: {ip_info.get('loc')}")
        print(f"{"\x1b[38;5;220m"}Organization: {ip_info.get('org')}")
        print(f"{"\x1b[38;5;220m"}════════════════════════════════════════════════════")
        print(f"")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred: {e}")

def get_url_info(url):
    try:
        result = subprocess.run(['nslookup', url], capture_output=True, text=True, check=True)
        nslookup_output = result.stdout.strip()

        print(f"")
        print(f"{"\x1b[38;5;220m"}════════════════════════════════════════════════════")
        print(f"{"\x1b[38;5;220m"}Results for: {url}")
        print(nslookup_output)
        print(f"{"\x1b[38;5;220m"}════════════════════════════════════════════════════")
        print(f"")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred: {e}")

def draw_banner():
    print("")
    print("")
    print(f"{art_colors[0]}                       ██████╗██╗   ██╗██████╗ ███████╗██████╗ ███╗   ██╗ █████╗ ██████╗  ██████╗ ")
    print(f"{art_colors[1]}                      ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗████╗  ██║██╔══██╗██╔══██╗██╔═══██╗")
    print(f"{art_colors[2]}                      ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝██╔██╗ ██║███████║██║  ██║██║   ██║")
    print(f"{art_colors[3]}                      ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██║╚██╗██║██╔══██║██║  ██║██║   ██║")
    print(f"{art_colors[4]}                      ╚██████╗   ██║   ██████╔╝███████╗██║  ██║██║ ╚████║██║  ██║██████╔╝╚██████╔╝")
    print(f"{art_colors[5]}                       ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ")
    print("")
    print("")
    print(f"")
    print(f"{"\x1b[38;5;166m"}               ╔═══════════════════════════════╗                     ╔═══════════════════════════════╗")
    print(f"{"\x1b[38;5;166m"}               ║  CyberNado By: atibocs        ║                     ║  info <IP>                    ║")
    print(f"{"\x1b[38;5;166m"}               ║  Version 1.0.0                ║                     ║  List information about the   ║")
    print(f"{"\x1b[38;5;166m"}               ║  Discord: AtibocsGaming       ║                     ║  given IP address.            ║")
    print(f"{"\x1b[38;5;166m"}               ║  Programming language: Python ║                     ║  surl <URL> Get data,         ║")
    print(f"{"\x1b[38;5;166m"}               ║                               ║                     ║  for a given URL.             ║")
    print(f"{"\x1b[38;5;166m"}               ║                               ║                     ║  Enter ''clear'' for clear    ║")
    print(f"{"\x1b[38;5;166m"}               ║                               ║                     ║  the terminal.                ║")
    print(f"{"\x1b[38;5;166m"}               ╚═══════════════════════════════╝                     ╚═══════════════════════════════╝")
    print(f"")
    print(f"")

def main():
    draw_banner()
    
    while True:
        command = input(f"{"\x1b[38;5;160m"}Enter A Command... >> ")
        
        if command.lower() == 'exit':
            break
        
        if command.lower() == 'clear':
            os.system('cls' if os.name == 'nt' else 'clear')
            draw_banner()
        
        elif command.startswith('info '):
            ip = command.split(' ')[1]
            get_ip_info(ip)
        elif command.startswith('surl '):
            url = command.split(' ')[1]
            get_url_info(url)
        else:
            print(f"{"\x1b[38;5;166m"}Unknown command!")

if __name__ == "__main__":
    main()
