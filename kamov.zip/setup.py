from cx_Freeze import setup, Executable

setup(
    name="Kamov",
    version="1.0",
    description="Developed by atibocs",
    executables=[Executable("kamov.py")]
)